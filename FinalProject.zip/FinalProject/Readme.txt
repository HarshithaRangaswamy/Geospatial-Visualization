To Run the project:

1. The system should have the environment with the following libraries set up.

Python 3.x

Libraries:
math
cv2
numpy
pandas
skimage


2. Move to the src folder.
3. Run the Code.py file using the following command.

	python Code.py

4. The output is redirected to the output folder.



import sys, math, urllib, io, operator
from tile_system import *
from quad_key import *
import PIL
from PIL import Image
def main():
	# This function runs the code for HW3
	lat1 = float(sys.argv[1])
	lon1 = float(sys.argv[2])
	lat2 = float(sys.argv[3])
	lon2 = float(sys.argv[4])
	# Define the base image fixed size. It should take longer as the required image gets larger.
	# 1<<12 is the workable size for us to open the result image efficiently
	BASE_SIZE = 1 << 12 
	MIN_TILE_SIZE = 1 << 6
	base = Image.new('RGB', (BASE_SIZE, BASE_SIZE))

	q, tx0, ty0 = get_Lowest_Quality(lat1, lon1, lat2, lon2)
	curr_tile_size = BASE_SIZE/2
	flag = True 
	# The full image with best resolution is updated after each iteration of double for loop
	best_result = base 
	while q <= 23 and curr_tile_size >= MIN_TILE_SIZE and flag:

		print "Fetch quality at ",
		print q
		print "curr_tile_size is",
		print curr_tile_size
		tx1, ty1 = LatLong_To_TileXY(lat1, lon1, q)
		tx2, ty2 = LatLong_To_TileXY(lat2, lon2, q)
		if tx1 > tx2:
			tx1, tx2 = tx2, tx1
		if ty1 > ty2:
			ty1, ty2 = ty2, ty1
		for x in xrange(tx1, tx2+1):
			if not flag:
				break
			for y in xrange(ty1, ty2+1):
				if not flag:
					break
				curr_quadKey = TileXY_To_QuadKey(x, y, q)

				try:
					curr_image = getImage_From_Quadkey(curr_quadKey)

					if not null_Result(curr_image):
						curr_image = curr_image.resize((curr_tile_size, curr_tile_size))
						start_x = (x - tx0) * curr_tile_size 
						start_y = (y - ty0) * curr_tile_size
						end_x = start_x + curr_tile_size
						end_y = start_y + curr_tile_size
						base.paste(curr_image, (start_x, start_y, end_x, end_y))
					else:
						flag = False
						print "can't find tile:",
						print x, 
						print y,
						print "at the quality level",
						print q
						break
				except:
					print "Bing connection problem"
					continue

		tx0 = tx0 * 2
		ty0 = ty0 * 2
		q += 1
		curr_tile_size /= 2
		if flag:
			best_result = base

	print "finish while loop"
	best_result.save('complete.jpeg')


if __name__ == '__main__':
	main()




import sys, math, urllib, io, operator
from tile_system import *
import PIL
from PIL import Image

def get_URL(quadkey):
	license_key = "Aj0e3I39LQF0KNkFrUUY1kz_rEI80XBB7cZJlbqRjSYx7iiAEwmSE74gFZmXqo0X"
	return "http://h0.ortho.tiles.virtualearth.net/tiles/h%s.jpeg?g=131&key=%s" % (quadkey, license_key)

#This function fetches image using quad key
def getImage_From_Quadkey(quadkey):
	socket = urllib.urlopen(get_URL(quadkey))
	tinker = socket.read()
	img = Image.open(io.BytesIO(tinker))
	return img

#This function gets the lowest quality image
def get_Lowest_Quality(lat1, lon1, lat2, lon2):

    i = 1

    for i in xrange(23, 0, -1):
        tx1, ty1 = LatLong_To_TileXY(lat1, lon1, i)
        tx2, ty2 = LatLong_To_TileXY(lat2, lon2, i)
        if tx1 > tx2:
            tx1, tx2 = tx2, tx1
        if ty1 > ty2:
            ty1, ty2 = ty2, ty1
        if (tx2 - tx1 <= 1) and (ty2 - ty1 <= 1):
            print "Lowest Quality found at ",
            print i
            return i, tx1, ty1
    print "Error: should not reach here"

#This function compares the result with null image
def null_Result(img):

    result = (img == Image.open('null.jpeg'))
    # print result
    return result
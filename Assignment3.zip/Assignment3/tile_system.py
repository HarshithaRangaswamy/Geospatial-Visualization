import math

EarthRadius = 6378137
MinLat = -85.05112878
MaxLat = 85.05112878
MinLong = -180
MaxLong = 180

#This function will clip a number to the specified min and max values
def Clip(n, minVal, maxVal):

	return min(max(n, minVal), maxVal)

#This function determines the map width and height in pixels
def Map_Size(levelOfDetail):

	return 256 << levelOfDetail

#This function determines the ground resolution in meters per pixel at a specified latitude and levelOfDetail
def Ground_Resolution(latitude, levelOfDetail):

	latitude = Clip(latitude, MinLat, MaxLat)
	return math.cos(latitude*math.pi / 180) * 2 * math.pi * EarthRadius / Map_Size(levelOfDetail)

#This function determines the map scale at a specified latitude, level of detail, and screen resolution.
def Map_Scale(latitude, levelOfDetail, screenDpi):

	return Ground_Resolution(latitude, levelOfDetail) * screenDpi/0.0254

#This function will convert a point from lat and long in degrees into pixel
def LatLong_To_PixelXY(latitude, longitude, levelOfDetail):

	latitude = Clip(latitude, MinLat, MaxLat)
	longitude = Clip(longitude, MinLong, MaxLong)

	x = (longitude + 180) / 360
	sinLatitude = math.sin(latitude * math.pi / 180)
	y = 0.5 - math.log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * math.pi)

	mapSize = Map_Size(levelOfDetail)
	pixelX = int(Clip(x * mapSize + 0.5, 0, mapSize - 1))
	pixelY = int(Clip(y * mapSize + 0.5, 0, mapSize - 1))

	return pixelX, pixelY

#This function converts from pixel into degrees
def PixelXY_To_LatLong(pixelX, pixelY, levelOfDetail):

	mapSize = Map_Size(levelOfDetail)
	x = (Clip(pixelX, 0, mapSize-1) / mapSize) - 0.5
	y = 0.5 - (Clip(pixelY, 0, mapSize - 1) / mapSize)

	latitude = 90 - 360 * math.atan(math.exp(-y * 2 * math.pi)) / math.pi
	longitude = 360 * x

	return latitude, longitude

#This function converts pixel X,Y coordinates into tile X, Y coordinates
def PixelXY_To_TileXY(pixelX, pixelY):

	tileX = int(pixelX / 256)
	tileY = int(pixelY / 256)
	return tileX, tileY

#this function converts tile X, Y coordinates into pixel X,Y coordinates
def TileXY_To_PixelXY(tileX, tileY):

	pixelX = tileX * 256
	pixelY = tileY * 256

#This function returns a quad key from the input tile X,Y coordinates
def TileXY_To_QuadKey(tileX, tileY, levelOfDetail):

	quadKey = ""
	for i in range(levelOfDetail, 0, -1):
		digit = '0'
		mask = 1 << (i-1)
		if ((tileX & mask) != 0):
			digit = chr(ord(digit) + 1)
		if ((tileY & mask) != 0):
			digit = chr(ord(digit) + 1)
			digit = chr(ord(digit) + 1)
		quadKey += digit
	return quadKey

#This function returns a quad key from the  latitude and longitude
def LatLong_To_QuadKey(latitude, longitude, levelOfDetail):

	pixelX, pixelY = LatLong_To_PixelXY(latitude, longitude, levelOfDetail)
	print "pixelX, pixelY are ",
	print pixelX,
	print pixelY
	tileX, tileY = PixelXY_To_TileXY(pixelX, pixelY)
	print "tileX, tileY are ",
	print tileX,
	print tileY
	quadKey = TileXY_To_QuadKey(tileX, tileY, levelOfDetail)
	print "quadKey is",
	print quadKey
	return quadKey

#This function is used to convert latitude and longitude to tile coordinates
def LatLong_To_TileXY(latitude, longitude, levelOfDetail):
	pixelX, pixelY = LatLong_To_PixelXY(latitude, longitude, levelOfDetail)
	tileX, tileY = PixelXY_To_TileXY(pixelX, pixelY)
	return tileX, tileY


if __name__ == '__main__':
    LatLong_To_QuadKey(42.052799, -87.673748, 2) # Northwestern QuadKey

